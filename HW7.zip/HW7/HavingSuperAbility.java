package HW7;

public interface HavingSuperAbility {
    void applySuperAbility();
}
