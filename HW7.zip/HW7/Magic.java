package HW7;

public class Magic extends Hero {
    @Override
    public void applySuperAbility() {
        System.out.println("Magic применил супер способность MAGIC WAVE");
    }
}
