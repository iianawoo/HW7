package HW7;

public abstract class Hero implements HavingSuperAbility {
    int health;
    int damage;
    String superAbilityType;
}

